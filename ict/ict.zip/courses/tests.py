from django.test import TestCase

# Create your tests here.
#https://www.geeksforgeeks.org/generate-a-pdf-in-django/
#https://www.geeksforgeeks.org/django-sign-up-and-login-with-confirmation-email-python/?ref=lbp
#https://ordinarycoders.com/blog/article/django-user-register-login-logout
